# Apexline redesign notes

- **Archetype:** Commercial project lifecycle and portfolio
- **Reference:** Southland Industries project scale and lifecycle organization
- **Audience:** General contractors, developers, owners, construction managers, design teams
- **Primary CTA:** Invite Apexline to bid
- **Visual direction:** Deep navy, blueprint blue, structural gray, sparing safety yellow, hard edges
- **Motion:** Blueprint grid drift and lifecycle state change; reduced-motion fallback included
- **Libraries:** Phosphor Icons; GSAP, Swiper, and PhotoSwipe intentionally deferred until real project media is supplied
- **Interaction:** Six-stage delivery lifecycle with project media and proof changes
- **Media required:** Jobsite video, mechanical room, riser, prefab shop, BIM screen, field crew
- **Changed structure:** Markets and lifecycle precede projects, field execution, bid requirements, and FAQ
- **SEO/accessibility:** Noindex, unique metadata, FAQ schema, video-style pause control, keyboard tabs, labeled bid form
