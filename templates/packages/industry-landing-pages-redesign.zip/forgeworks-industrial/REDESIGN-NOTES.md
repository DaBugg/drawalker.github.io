# Forgeworks redesign notes

- **Archetype:** Technical specification console and manufacturing story
- **Reference:** Fictiv capability clarity; original industrial execution
- **Audience:** Engineers, procurement managers, project managers, operations teams
- **Primary CTA:** Submit an RFQ
- **Visual direction:** Graphite, technical paper, oxidized orange, fine grid, square geometry
- **Motion:** Route-line style component callouts and measured state changes
- **Libraries:** Phosphor Icons only; model-viewer and GSAP intentionally deferred until real media exists
- **Interaction:** Manufacturing process specification selector and RFQ package preview
- **Media required:** Exploded assembly, CNC close-up, welded skid, inspection, shipment, drawing preview
- **Changed structure:** Replaced generic benefits/steps/testimonial flow with process, material, traceability, lifecycle, assemblies, and RFQ requirements
- **SEO/accessibility:** Retains noindex, unique metadata, FAQ schema, skip link, labeled form, focus states, reduced motion, and fallback text
