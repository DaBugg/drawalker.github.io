(() => {
  const menu = document.querySelector('[data-menu]');
  const nav = document.querySelector('.site-header nav');
  menu?.addEventListener('click', () => { const open = nav.classList.toggle('open'); menu.setAttribute('aria-expanded', open); });
  const specs = {
    machining:['3- and 5-axis CNC machining','Tight-tolerance parts and short production runs','STEP file, PDF drawing, material, quantity','Inspected parts with requested records'],
    fabrication:['Welded fabrication and assemblies','Skids, frames, supports, and repeatable weldments','Drawing set, weld notes, finish, release plan','Labeled assembly with inspection summary'],
    piping:['Shop-built process piping','Spools and coordinated piping packages','Isometrics, line class, NDE, test requirements','Tested spools grouped by system or area'],
    finishing:['Surface preparation and coating coordination','Parts requiring controlled appearance or protection','Substrate, preparation standard, coating system','Finished components with batch records']
  };
  const fields = ['name','best','inputs','output'];
  document.querySelectorAll('[data-process]').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('[data-process]').forEach(item => item.setAttribute('aria-selected','false'));
    button.setAttribute('aria-selected','true');
    specs[button.dataset.process].forEach((value,index) => document.querySelector(`[data-spec="${fields[index]}"]`).textContent = value);
  }));
  const form = document.querySelector('[data-form]');
  form?.addEventListener('submit', async event => {
    event.preventDefault(); let valid = true;
    form.querySelectorAll('[required]').forEach(field => { const error = form.querySelector(`[data-error="${field.name}"]`); let message = field.value.trim() ? '' : 'This field is required.'; if (!message && field.type === 'email' && !/^\S+@\S+\.\S+$/.test(field.value)) message = 'Enter a valid email.'; error.textContent = message; field.setAttribute('aria-invalid', Boolean(message)); valid = valid && !message; });
    const status = form.querySelector('.form-status'); if (!valid) { status.textContent = 'Review the highlighted fields.'; form.querySelector('[aria-invalid="true"]')?.focus(); return; }
    const button = form.querySelector('button'); button.disabled = true; button.textContent = 'Reviewing package…'; await new Promise(resolve => setTimeout(resolve,600)); form.reset(); button.disabled = false; button.textContent = button.dataset.label; status.textContent = 'RFQ captured for this demo. Connect a secure endpoint before launch.';
  });
})();
