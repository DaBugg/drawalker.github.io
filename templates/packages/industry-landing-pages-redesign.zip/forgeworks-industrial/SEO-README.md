# SEO and launch notes

## Current index recommendation

This fictional concept ships with `noindex, nofollow` and a blocked `robots.txt` to avoid indexing a fictional company or duplicate template copy.

Before production launch:

1. Replace fictional proof, reviews, metrics, location, and schema URL.
2. Change the robots meta tag to `index, follow`.
3. Replace `robots.txt` with production crawl rules and add a sitemap URL.
4. Add the verified canonical production URL.
5. Replace the local SVG social image with a final 1200 by 630 image.
6. Connect the form to a secure service and publish a complete privacy policy.
7. Validate FAQ and organization schema.

## Search positioning

**Primary offer:** A technical quote for fabricated assemblies, process piping components, and project supply packages.

**Primary audience:** Plant managers, procurement teams, mechanical contractors, and equipment manufacturers.

**Primary conversion:** Request a technical quote

**Title:** Industrial Fabrication and Supply Quote | Forgeworks

**Meta description:** Request a technical quote for fabricated assemblies, process piping components, project supply packages, and organized documentation.

**Layout:** Technical procurement console. Search intent is organized around process capabilities, materials, tolerances, traceability, lead times, and RFQ requirements.
