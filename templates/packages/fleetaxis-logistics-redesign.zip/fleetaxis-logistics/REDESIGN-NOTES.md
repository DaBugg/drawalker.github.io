# FleetAxis redesign notes

- **Archetype:** Interactive route map and shipment control tower
- **Reference:** Flexport's service-plus-visibility structure
- **Audience:** Manufacturers, importers, contractors, distributors, operations teams
- **Primary CTA:** Build a freight quote
- **Visual direction:** Deep navy, electric blue, signal orange, selective operational density
- **Motion:** Route-line animation and milestone state; reduced-motion fallback
- **Libraries:** Phosphor Icons; MapLibre, Chart.js, and GSAP deferred until production data is available
- **Interaction:** Origin/destination/equipment route builder with live map summary
- **Media required:** Route map, port movement, project cargo, loading, dashboard, handoff timeline
- **Changed structure:** Quote/map, modes, visibility, project cargo, coverage, requirements, FAQ
- **SEO/accessibility:** Noindex, FAQ schema, labeled controls, readable map fallback, focus/reduced-motion support
