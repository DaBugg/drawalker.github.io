# RapidRoot redesign notes

- **Archetype:** Task-based local service booking
- **Reference:** Service Champions conversion clarity and Eco's local personality
- **Audience:** Palm Beach County homeowners needing plumbing, cooling, or electrical help
- **Primary CTA:** Schedule service; call remains an urgent secondary action
- **Visual direction:** Clear blue, fresh green, warm yellow, friendly high-contrast controls
- **Motion:** Fast selector/accordion feedback only; no scroll effects or animation library
- **Libraries:** Phosphor Icons; Swiper and MapLibre avoided until real reviews or coverage data justify them
- **Interaction:** Service issue selector, ZIP check, and sticky mobile conversion bar
- **Media required:** Technician arrival, vehicle, service work, consultation, before/after detail
- **Changed structure:** Booking and availability lead; trust, services, visit, reviews, FAQ follow
- **SEO/accessibility:** Noindex, FAQ schema, large touch targets, labels, live feedback, reduced motion
