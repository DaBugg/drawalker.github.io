# Palm Coast Clinic redesign notes

- **Archetype:** Patient-first task and condition navigation
- **Reference:** HSS task access and Rothman condition/provider organization
- **Audience:** Adults and athletes with pain, injury, mobility, or rehabilitation needs
- **Primary CTA:** Book an evaluation
- **Visual direction:** White, ocean blue, soft teal, warm neutral, generous space
- **Motion:** Minimal focus and accordion transitions only
- **Libraries:** Phosphor Icons; MapLibre, Swiper, and PhotoSwipe deferred until verified location/media data exist
- **Interaction:** Find-care search and body-area care pathway selector
- **Media required:** Clinician evaluation, rehabilitation, active senior, portraits, clinic, in-home visit
- **Changed structure:** Find care, conditions, options, clinicians, first visit, insurance, locations, appointment
- **SEO/accessibility:** Noindex, MedicalClinic and FAQ schema, non-diagnostic language, emergency caveat, labeled form
